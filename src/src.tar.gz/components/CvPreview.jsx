import React from "react";
import CvTitle from "./CvTitle";

const CvPreview = () => {
  return (
    <div className="cv-preview has-background-white">
      <CvTitle></CvTitle>
    </div>
  );
};

export default CvPreview;
