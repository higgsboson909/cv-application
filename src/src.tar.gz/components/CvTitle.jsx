import React from 'react'

const CvTitle = () => {
  return (
    <section className='section'>
    <div></div>
    </section>
  )
}

export default CvTitle
